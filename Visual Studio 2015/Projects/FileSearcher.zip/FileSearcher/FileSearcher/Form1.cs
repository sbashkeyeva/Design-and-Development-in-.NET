﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace FileSearcher
{
    public partial class Form1 : Form
    {
        Form1.Size = new System.Drawing.Size(100, 100); 
            Form1.Width = 300;  
            Form1.Size = new Size(300, Form1.Size.Height);
        public Form1()
        {
            InitializeComponent();
            //this.BackColor = Color.FromArgb(230, 230, 250);
            
              //  this.BackColor = Color.FromArgb(127, 255, 212);
            //this.ForeColor = Color.FromArgb(32, 178, 170);
            this.BackColor = Color.FromArgb(216, 191, 216);
            this.Opacity = 0.7;
            txtSearchDirectory.BackColor = Color.FromArgb(255, 250, 250);
            listBox1.BackColor = Color.FromArgb(255, 250, 250);
            txtSearchFile.BackColor = Color.FromArgb(255, 250, 250);
            
        }
        string strSearchDirectory;
        List<string> myList = new List<string>();
        private void Form1_Load(object sender, EventArgs e)
        {
            strSearchDirectory = txtSearchDirectory.Text;
            txtSearchDirectory.ReadOnly = true;
           
        }
        
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if(fbd.ShowDialog()==DialogResult.OK)
            {
                strSearchDirectory = fbd.SelectedPath;
                txtSearchDirectory.Text = strSearchDirectory;
            }
        }
        
        public static void Search(DirectoryInfo dir, string reg,List<string> myList)
        {
            Regex rgx = new Regex(reg);
            try
            {
                foreach(var dirs in dir.GetDirectories())
                {
                    if(Path.GetFileNameWithoutExtension(dirs.Name.ToLower()).Contains(reg.ToLower()))
                    {
                        if(!myList.Contains("[♨]" + dirs.Name))
                        {
                            myList.Add("[♨]" + dirs.Name);
                        }
                    }
                    Search(dirs, reg, myList);
                }
                foreach(var files in dir.GetFiles())
                {
                    if(Path.GetFileNameWithoutExtension(files.Name.ToLower()).Contains(reg.ToLower()))
                    {
                        if(rgx.IsMatch(files.Name))
                        {
                            myList.Add(files.Name);
                        }
                    }
                    
                }

            }
            catch
            {
                Console.WriteLine("Oops!");
            }
        }
        public void Search(DirectoryInfo dir,string reg,List<string> myList,DateTime dt1,DateTime dt2)
        {
            Regex rgx = new Regex(reg);
            try
            {
                foreach(var dirs in dir.GetDirectories())
                {
                    if (Path.GetFileNameWithoutExtension(dirs.Name.ToLower()).Contains(reg.ToLower()))
                    {
                        if(!myList.Contains("[♨]" + dirs.Name))
                        {
                            myList.Add("[♨]" + dirs.Name);
                        }
                        Search(dirs, reg, myList, dt1, dt2);
                    }
                }
                foreach(var files in dir.GetFiles())
                {
                    if(Path.GetFileNameWithoutExtension(files.Name.ToLower()).Contains(reg.ToLower()))
                    {
                        DateTime tm = File.GetCreationTime(files.FullName);
                        if(rgx.IsMatch(files.Name) && dt1<tm && dt2>tm)
                        {
                            myList.Add(files.Name);
                        }
                    }

                }
            }
            catch
            {
                Console.WriteLine("Oops:(");
            }
        }
        //Dictionary<string,string> curFullpath=new Dictionary<string, string>();
        private async void btnSearch_Click(object sender, EventArgs e)
        {
            //DirectoryInfo infoDi = new DirectoryInfo(strSearchDirectory);
            //FileInfo[] infoFi = infoDi.GetFiles();
            //FileStream fis = new FileStream(strSearchDirectory,FileMode.Open,);
            myList.Clear();
            string s = txtSearchFile.Text;
            DirectoryInfo infoDi = new DirectoryInfo(strSearchDirectory);
            string strSearchFile = txtSearchFile.Text;
            listBox1.Items.Clear();
            if(!checkBox1.Checked)
            {
                
                Search(infoDi, s, myList);
            }
            if(checkBox1.Checked)
            {
                strSearchDirectory = txtSearchDirectory.Text;
                Search(infoDi, s, myList);
                DateTime dt1 = dateTimePicker1.Value;
                textBox1.Text = dt1.ToString("dd-mm-yyyy");
                DateTime dt2 = dateTimePicker2.Value;
                textBox2.Text = dt2.ToString("dd-mm-yyyy");
                Search(infoDi, s, myList, dt1, dt2);

            }
            if(myList.Count==0)
            {
                MessageBox.Show("There is no such file:(");
            }
            listBox1.DataSource = null;
            listBox1.DataSource = myList;
            /*foreach (FileInfo curFile in infoFi)
            {
                if (curFile.Name.ToUpper().IndexOf(strSearchFile.ToUpper()) != -1)
                {
                    listBox1.Items.Add(curFile.Name);
                    //curFullpath[curFile.Name] = curFile.FullName;

                    //Process.Start(curFullpath[curFile.FullName]);
                }
            }
            txtSearchFile.Clear();
            txtSearchFile.Focus();*/

        }
        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            //int index = listBox1.IndexFromPoint(e.Location);
            string file = listBox1.SelectedItem.ToString();
            foreach(var p in myList)
            {
                if(file.Contains("[♨]"))
                {
                    file = file.Substring(3);
                }
                if(p.Contains(file))
                {
                    Process.Start(p);
                    break;
                }
            }
            //strSearchDirectory+= file;
            //txtSearchDirectory.Text = strSearchDirectory;
           // curFullpath[file] = strSearchDirectory;
          //  Process.Start(strSearchDirectory);
            /*if(File.Exists(file))
            {
                FileInfo myFile = new FileInfo(file);
                TextReader myData = myFile.OpenText();

            }*/
            /*if (index != ListBox.NoMatches)
            {
                Process.Start(index.ToString());
                //MessageBox.Show(index.ToString());
                //Process.Start(@"\\Mac\Home\Desktop\KBTU\labs\lab4.sql");
            }*/
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
           // this.BackColor = Color.FromArgb(230, 230, 250);
         //   this.TransparencyKey = Color.Turquoise;
          //  this.Opacity = 0.7;
            
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            if (op.ShowDialog() == DialogResult.OK)
            {
                txtSearchDirectory.Text = op.FileName;
            }
            try
            {
                try
                {
                    string[] lines = File.ReadAllLines(txtSearchFile.Text);
                    foreach(string line in lines)
                    {
                        listBox1.Items.Add(line);
                    }
                }
                catch
                {

                }
            }
            catch
            {

            }
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            /* foreach (string dir in Directory.GetDirectories(@"C:\\"))
            {
                DirectoryInfo info = new DirectoryInfo(dir);
                listBox1.Items.Add(info.Name);
            }
            foreach(string file in Directory.GetFiles(@"C:\\"))
            {
                FileInfo info = new FileInfo(file);
                listBox1.Items.Add(info.Name);
            }*/
        }


    }
}
